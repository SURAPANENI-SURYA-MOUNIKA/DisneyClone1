# Disney+ Hostar Clone 
![image](https://github.com/Ashutosh0120/HostarClone/assets/24804042/6e96f815-6537-4d5d-8433-30d77af04737)

Tech Stack: ```HTML``` ```CSS``` ```JS```
